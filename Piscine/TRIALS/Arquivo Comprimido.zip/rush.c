/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gadoglio <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/10/05 11:22:31 by gadoglio          #+#    #+#             */
/*   Updated: 2019/10/05 12:26:49 by gadoglio         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int g_i = 1;
int g_j = 1;

void	ft_putchar(char choice);

void	ft_line(int g_j, int x)
{
	if (g_j == 1 || g_j == x)
	{
		ft_putchar('o');
	}
	else
	{
		ft_putchar('-');
	}
}

void	ft_column(int g_j, int x)
{
	if (g_j == 1 || g_j == x)
	{
		ft_putchar('|');
	}
	else
	{
		ft_putchar(' ');
	}
}

void	rush(int x, int y)
{
	while (g_i <= y)
	{
		while (g_j <= x)
		{
			if (g_i == 1 || g_i == y)
			{
				ft_line(g_j, x);
			}
			else
			{
				ft_column(g_j, x);
			}
			g_j++;
		}
		g_j = 1;
		ft_putchar('\n');
		g_i++;
	}
}
